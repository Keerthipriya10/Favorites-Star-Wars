from django.contrib import admin
from .models import Plnt_Mvs,Favr
# Register your models here.
admin.site.register(Plnt_Mvs)
admin.site.register(Favr)