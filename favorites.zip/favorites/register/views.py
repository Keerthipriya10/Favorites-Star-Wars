from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate
from .models import Plnt_Mvs,Favr
from django.contrib import messages
from .forms import UserRegisterForm
# Create your views here.

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            messages.success(request, f'Account created for {username}!')
            return redirect('/home')
    else:
        form = UserRegisterForm()
    return render(request, 'register/register.html', {'form': form})
def SearchPage(request):
	try:
		srh = request.GET['query']
	except:
		srh=''
	products = Plnt_Mvs.objects.filter(name__contains=srh)
	params = {'products': products, 'search':srh}
	return render(request, 'searchpage.html', params) 
def add_favorite(request):	
	if request.method=="POST":
		for i in request.POST:
			print(i)
		username=User.objects.get(username=request.user.username)
		favrte=request.POST.get('head')
		print(username,favrte)
		if Favr.objects.filter(username=username,favrte=favrte).exists():
			return render(request,'add_favorites.html',{'message':"Its already in favorites"})
		else:
			m=Favr(username=username,favrte=favrte)
			m.save()
			return render(request,'add_favorites.html',{'message':"Successfully added to favorites"})
	else:
		return render(request,'add_favorites.html',{'message':"Couln't add to favorites"})

def remove_favorite(request):
	print('In remove function')	
	if request.method=="POST":
		favrte=request.POST.get('removetitle')
		instance=Favr.objects.filter(username=request.user.username,favrte=favrte)
		if instance:
			Favr.objects.filter(username=request.user.username,favrte=favrte).delete()
	data = list(Favr.objects.filter(username=request.user.username))
	favrts=[]
	for i in data:
		favrts.append(i.favrte)
		print(i.favrte)
	return render(request,'view_favorite.html',{'response':favrts})

