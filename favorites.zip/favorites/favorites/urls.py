"""favorites URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from django.conf.urls.static import static
from django.urls import path, include
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings
from register import views as v
#
urlpatterns = [
path('admin/', admin.site.urls),
url(r'^$', views.home),
path('', include("django.contrib.auth.urls")),
url('home',views.home,name = "home"),
path('register/', v.register, name='register'),
url('favr',views.favr,name="favr"),
url('planets',views.planets,name="planets"),
url('movies',views.movies,name="movies"),
url('mypl',views.mypl,name="mypl"),
url('mymo',views.mymo,name="mymo"),
url('view_favorite',views.view_favorite,name="view_favorite"),
path('search',v.SearchPage,name="search_result"),
url('add_favorite',v.add_favorite,name="add_favorite"),
path('remove_favorite',v.remove_favorite,name="remove_favorite"),
]
urlpatterns += staticfiles_urlpatterns()
urlpatterns+= static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
