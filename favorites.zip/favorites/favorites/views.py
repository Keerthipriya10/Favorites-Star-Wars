from django.shortcuts import render
import requests
import sys
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth.decorators import login_required
from register.models import Favr

def log(request):
	return render(request,'login_template.html')
def home(request):
    return render(request,'home.html')
def favr(request):
    return render(request,'favr.html')
def view_favorite(request):
	data = list(Favr.objects.filter(username=request.user.username))
	favrts=[]
	for i in data:
		favrts.append(i.favrte)
		print(i.favrte)
	return render(request,'view_favorite.html',{'response':favrts})

def planets(request):
	response = requests.get('https://swapi.dev/api/planets/').json()
	print("planets data received")
	return render(request,'planets.html',{'response':response})
def movies(request):
	response = requests.get('https://swapi.dev/api/films/').json()
	print("moviess data received")
	return render(request,'movies.html',{'response':response})
def mypl(request):
	response = requests.get('https://swapi.dev/api/planets/').json()
	print("planets data received")
	return render(request,'mypl.html',{'response':response})
def mymo(request):
	response = requests.get('https://swapi.dev/api/films/').json()
	print("moviess data received")
	return render(request,'mymo.html',{'response':response})
